import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import Profile from "./Components/Profile";
import Role from "./Components/Role";
function App() {
  return (
    <div>
      <Router>
        <div>
          <Routes>
            <Route path="/Profile" element={<Profile />} />
            <Route path="/" element={<Role />} />
            </Routes>
        </div>

      </Router>
    </div>
  );
}

export default App;
