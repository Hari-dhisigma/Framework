import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import Profile from "./Components/Profile";
import Role from "./Components/Role";
import Login from "./Components/Login";
import Sample from "./Components/test";

function App() {
  return (
    <div>
      <Router>
        <div>
          <Routes>
            <Route path="/Profile" element={<Profile />} />
            <Route path="/Role" element={<Role />} />
            <Route path="/" element={<Login />} />
            <Route path="/sample" element={<Sample />} />
            </Routes>
        </div>

      </Router>
    </div>
  );
}

export default App;
