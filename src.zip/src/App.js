import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import AddUser from "./Components/AddUser";
import AddRole from "./Components/AddRole";
import Login from "./Components/Login";
import Sample from "./Components/test";
import Dashboard from "./Components/Dashboard";
import RoleList from "./Components/RoleList";
import AddCompany from "./Components/AddCompany";
import CompanyList from "./Components/CompanyList";
import UserList from "./Components/UserList";
import Policy from "./Components/Policy";
function App() {
  return (
    <div>
      <Router>
        <div>
          <Routes>
            <Route path="/AddUser" element={<AddUser />} />
            <Route path="/AddRole" element={<AddRole />} />
            <Route path="/" element={<Login />} />
            <Route path="/sample" element={<Sample />} />
            <Route path="/Dashboard" element={<Dashboard />} />
            <Route path="/RoleList" element={<RoleList />} />
            <Route path="/AddCompany" element={<AddCompany />} />
            <Route path="/CompanyList" element={<CompanyList />} />
            <Route path="/UserList" element={<UserList />} />
            <Route path="/Policy" element={<Policy />} />
            </Routes>
        </div>

      </Router>
    </div>
  );
}

export default App;
