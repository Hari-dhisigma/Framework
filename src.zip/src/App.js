import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import Profile from "./Components/Profile";
import Role from "./Components/Role";
import Login from "./Components/Login";

function App() {
  return (
    <div>
      <Router>
        <div>
          <Routes>
            <Route path="/Profile" element={<Profile />} />
            <Route path="/" element={<Role />} />
            <Route path="/Login" element={<Login />} />
            </Routes>
        </div>

      </Router>
    </div>
  );
}

export default App;
