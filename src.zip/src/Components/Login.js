
import './Login.css';
import { Form, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useEffect, useState } from "react";
import axios from "axios";

function Login() {
  const [Username, setUsername] = useState("");
  const [Password, setPassword] = useState("");
  const [token, setToken]=useState('');

  function handleClick(e){
    e.preventDefault();
    let reqst={"username":Username, "password":Password};
    let url="http://localhost:8000/logincheck";
    let header={ };
    console.log("req=>"+JSON.stringify(reqst));
    console.log("url=>"+url);
    axios.post(
        url,reqst,header
    ).then(
        (res)=>{
            console.log(res.data)
            console.log(res.data.token)
            setToken(res.data.token);
            alert("login success")
        }
    ).catch(function (error) {
        console.log(error);
      });
}
  return (
    <div className='containerLog'>
        <div className='formLog'>
        <Form>
  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Username</Form.Label>
    <Form.Control type="txt" placeholder="Enter Username" onChange={(e)=>{setUsername(e.target.value)}}/>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password" onChange={(e)=>{setPassword(e.target.value)}} />
  </Form.Group>
  <Button variant="primary" type="submit" onClick={(e)=>handleClick(e)}>
    Login
  </Button>
</Form>
    </div>
    </div>
  );
}

export default Login;
