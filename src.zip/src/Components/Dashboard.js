import "bootstrap/dist/css/bootstrap.min.css";
import "./Dashboard.css";
import React from "react";
import { Link } from "react-router-dom";

function Dashboard() {
  function session() {
    sessionStorage.clear();
  }
  return (
    <div>
      <div class="topnav">
        <Link to="/Dashboard">Dashboard</Link>
      </div>

      <div class="sidenav">
        <Link to="/RoleList">Roles</Link>
        <Link to="/CompanyList">Company</Link>
        <Link to="/UserList">Users</Link>
        <Link to="/Policy">Policy</Link>
        <Link to="/" onClick={session}>
          Logout
        </Link>
      </div>
    </div>
  );
}

export default Dashboard;
