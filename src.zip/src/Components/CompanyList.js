import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import React, { useEffect, useState } from "react";
import "./CompanyList.css";
import Dashboard from "./Dashboard";
import { Link } from "react-router-dom";

function CompanyList() {
  const [CList, setCList] = useState([]);
 
  useEffect(() => {
   
  
    axios
    .get('http://localhost:8000/TenantFetch')
    .then(function (res) {
      console.log(res.data.Items);
      setCList(res.data.Items)
    })
    .catch(function (error) {
      console.log(error);
    });
  }, []);
  return (
    <div>
      <Dashboard />
      <div class="containerOrder">
        <h4>Company</h4>
      </div>
      <div class="btnAddOrder">
        <Link to="/AddCompany">
          <button type="button" class="btn btn-success">
            Add Company
          </button>
        </Link>
        </div>
      <div className="AppOrder">
        <table>
          <tr>
    
            <th>Tenant name</th>
            <th>Address</th>
        
          </tr>
          {CList.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val.tnm}</td>
                <td>{val.tsaddr}</td>
            
              </tr>
            );
          })}
        </table>
      </div>
    </div>
  );
}
export default CompanyList;