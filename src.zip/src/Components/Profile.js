
import './Profile.css';
import { Form, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { v4 as uuidv4 } from 'uuid';

function Profile() {
  const [List, setList] = useState([]);
  const [Number, setNumber] = useState("");
  const [Role, setRole] = useState("");
  const [Name, setName] = useState("");
  const [Password, setPassword] = useState("");
  const [Email, setEmail] = useState("");
  const [Tenant, setTenant] = useState("");
  const [TenantList, setTenantList] = useState([]);
  const [id, setId] = useState();
  const [tId, setTid] = useState();

  
  useEffect(() => {
  axios
      .get('http://localhost:8000/fetch')
      .then(function (res) {
        console.log(res.data.Items);
        setList(res.data.Items)
      })
      .catch(function (error) {
        console.log(error);
      });

      axios
      .get('http://localhost:8000/TenantFetch')
      .then(function (res) {
        console.log(res.data.Items);
        setTenantList(res.data.Items)
      })
      .catch(function (error) {
        console.log(error);
      });
    }, []);

    const profileInsert = (e) => {
     
        console.log(id);
      console.log(Role);
      e.preventDefault();
      let text1="P#";
      let s1=text1.concat(Number)
      const u=uuidv4();
   
      let text2 = "R#";
      let s2 = text2.concat(id);

      let text3 = "T#";
      let s3 = text3.concat(u);
        console.log(u);
        console.log(s1);
        console.log(s2);
        console.log(s3);
      var dt ={
      "TableName":"usrs",
          "Item":{
              Pk:Number,
              Sk:s1,
              unm:Name,
              pwd:Password,
              eml:Email,
              sts:"ACTIVE",
              id:Number
             
             
          }
        }
        console.log(dt);
        
        var dt2 ={
          "TableName":"usrs",
              "Item":{
                  Pk:Number,
                  Sk:s2,
                  unm:Name,
                  pwd:Password,
                  eml:Email,
                  sts:"ACTIVE",
                  id:id,
                  rnm:Role
                 
                 
              }
            }

            var dt3 ={
              "TableName":"usrs",
                  "Item":{
                      Pk:Number,
                      Sk:s3,
                      unm:Name,
                      pwd:Password,
                      eml:Email,
                      sts:"ACTIVE",
                      id:tId,
                      tnm:Tenant
                     
                     
                  }
                }

        axios
        .post('http://localhost:8000/userInsert', dt)
        .then(function (res) {
          console.log(res);
          // alert("user inserted")
        })
        .catch(function (error) {
          console.log(error);
        });

        axios
        .post('http://localhost:8000/userInsert', dt2)
        .then(function (res) {
          console.log(res);
          // alert("user inserted")
        })
        .catch(function (error) {
          console.log(error);
        });

        axios
        .post('http://localhost:8000/userInsert', dt3)
        .then(function (res) {
          console.log(res);
          alert("user inserted")
        })
        .catch(function (error) {
          console.log(error);
        });
    };

   

    
    function getRole(e){
      setRole(e.target.value)
      for(let i=0;i<List.length;i++){
console.log(List[i].rlnm);
        if(List[i].rlnm==e.target.value){
          setId(List[i].Pk)
        }
      }
        
      }

      function getTenant(e){
        setTenant(e.target.value)
        for(let i=0;i<List.length;i++){
  console.log(TenantList[i].tnm);
          if(TenantList[i].tnm==e.target.value){
            setTid(TenantList[i].Pk)
          }
        }
          
        }

  return (
    <div className='containerProfile'>
        <div className='formProfile'>
<Form>
<Form.Group className="mb-3" controlId="formBasicName">
    <Form.Label> Phone Number</Form.Label>
    <Form.Control type="text" placeholder="Enter Phone Number" value={Number}
              onChange={(e) => setNumber(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicName">
    <Form.Label> Username</Form.Label>
    <Form.Control type="text" placeholder="Enter Username" value={Name}
              onChange={(e) => setName(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label> Password</Form.Label>
    <Form.Control type="password" placeholder="Enter Password" value={Password}
              onChange={(e) => setPassword(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
    <Form.Label>Email</Form.Label>
    <Form.Control type="text" placeholder="Enter Email" value={Email}
              onChange={(e) => setEmail(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
  <Form.Label>Role</Form.Label>
  <Form.Select aria-label="Default select example" onChange={(e) => getRole(e)} >
  
 <option value="none" selected disabled hidden>
              select a role
            </option>
            {List.map((itm, indx) => {

              return (

                <option >
                 
                  {itm.rlnm}
                </option>
              );
            })}
</Form.Select>
</Form.Group>

<Form.Group className="mb-3" controlId="formBasicAddress">
<Form.Label>Company Tenant</Form.Label>
  <Form.Select aria-label="Default select example" onChange={(e) => getTenant(e)}>
  <option value="none" selected disabled hidden>
              select a role
            </option>
            {TenantList.map((itm, indx) => {

              return (

                <option >
                 
                  {itm.tnm}
                </option>
              );
            })}
</Form.Select>
</Form.Group>
  <Button variant="primary" type="submit" onClick={(e) =>profileInsert(e)}>
    Submit
  </Button>
</Form>
    </div>
    </div>
  );
}

export default Profile;
