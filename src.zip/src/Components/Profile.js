
import './Profile.css';
import { Form, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useEffect, useState } from "react";
import axios from "axios";

function Profile() {
  const [List, setList] = useState([]);
  const [Role, setRole] = useState("");
  const [Name, setName] = useState("");
  const [Address, setAddress] = useState("");
  const [Terrant, setTerrant] = useState("");
  useEffect(() => {
  axios
      .get('http://localhost:8000/fetch')
      .then(function (res) {
        console.log(res.data.Items);
        setList(res.data.Items)
        console.log({List});
      })
      .catch(function (error) {
        console.log(error);
      });
    }, []);

    const profileInsert = (e) => {
      e.preventDefault();
      var dt ={
      "TableName":"tblusers",
          "Item":{
              name:Name,
              address:Address,
              role:Role,
              terrant:Terrant
             
             
          }
        }
        console.log(dt);
        
        axios
        .post('http://localhost:8000/userInsert', dt)
        .then(function (res) {
          console.log(res);
          alert("user inserted")
        })
        .catch(function (error) {
          console.log(error);
        });
    };

  return (
    <div className='containerProfile'>
        <div className='formProfile'>
<Form>
  <Form.Group className="mb-3" controlId="formBasicName">
    <Form.Label>Full Name</Form.Label>
    <Form.Control type="text" placeholder="Enter Full Name" value={Name}
              onChange={(e) => setName(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
    <Form.Label>Address</Form.Label>
    <Form.Control type="text" placeholder="Address" value={Address}
              onChange={(e) => setAddress(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
  <Form.Label>Role</Form.Label>
  <Form.Select aria-label="Default select example" onChange={(e) => setRole(e.target.value)} >
  
 <option value="none" selected disabled hidden>
              select a role
            </option>
            {List.map((itm, indx) => {
              return (
                <option >
                  {itm.txtRole}
                </option>
              );
            })}
</Form.Select>
</Form.Group>

<Form.Group className="mb-3" controlId="formBasicAddress">
<Form.Label>Company Terrant</Form.Label>
  <Form.Select aria-label="Default select example" onChange={(e) => setTerrant(e.target.value)}>
  <option>Open this select menu</option>
  <option>bijus</option>
  <option>dev factory</option>
  <option>dhisigma</option>
</Form.Select>
</Form.Group>
  <Button variant="primary" type="submit" onClick={(e) =>profileInsert(e)}>
    Submit
  </Button>
</Form>
    </div>
    </div>
  );
}

export default Profile;
