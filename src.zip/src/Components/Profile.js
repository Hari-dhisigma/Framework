
import './Profile.css';
import { Form, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useEffect, useState } from "react";
import axios from "axios";

function Profile() {
  const [Role, setRole] = useState([]);
  const [Name, setName] = useState("");
  const [Address, setAddress] = useState("");

  useEffect(() => {
  axios
      .get('http://localhost:8000/fetch')
      .then(function (res) {
        console.log(res.data.Items);
        setRole(res.data.Items)
        console.log({Role});
      })
      .catch(function (error) {
        console.log(error);
      });
    }, []);

    function profileInsert() {
      
      var dt ={
      "TableName":"tblRoles",
          "Item":{
              id:8,
              txtRole:Role
             
             
          }
        }
        
        
        axios
        .post('http://localhost:8000/insert', dt)
        .then(function (res) {
          console.log(res);
          alert(res.data)
        })
        .catch(function (error) {
          console.log(error);
        });
    };

  return (
    <div className='containerProfile'>
        <div className='formProfile'>
<Form>
  <Form.Group className="mb-3" controlId="formBasicName">
    <Form.Label>Full Name</Form.Label>
    <Form.Control type="text" placeholder="Enter Full Name" value={Name}
              onChange={(e) => setName(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
    <Form.Label>Address</Form.Label>
    <Form.Control type="text" placeholder="Address" value={Address}
              onChange={(e) => setAddress(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicAddress">
  <Form.Label>Role</Form.Label>
  <Form.Select aria-label="Default select example"  >
  {/* onChange={(e) => setRole(e.target.value)} */}
 <option value="none" selected disabled hidden>
              select a role
            </option>
            {Role.map((itm, indx) => {
              return (
                <option >
                  {itm.txtRole}
                </option>
              );
            })}
</Form.Select>
</Form.Group>

<Form.Group className="mb-3" controlId="formBasicAddress">
<Form.Label>Company Terrant</Form.Label>
  <Form.Select aria-label="Default select example">
  <option>Open this select menu</option>
  <option>option 1</option>
  <option>option 2</option>
  <option>option 3</option>
</Form.Select>
</Form.Group>
  <Button variant="primary" type="submit" onClick={profileInsert}>
    Submit
  </Button>
</Form>
    </div>
    </div>
  );
}

export default Profile;
