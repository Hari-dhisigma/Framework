import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import React, { useEffect, useState } from "react";
import "./UserList.css";
import Dashboard from "./Dashboard";
import { Link } from "react-router-dom";

function UserList() {
  const [UList, setUList] = useState([]);
 
  useEffect(() => {
   
  
    axios
    .get('http://localhost:8000/fetchUser')
    .then(function (res) {
      console.log(res.data.Items);
      setUList(res.data.Items)
    })
    .catch(function (error) {
      console.log(error);
    });
  }, []);
  return (
    <div>
      <Dashboard />
      <div class="containerUser">
        <h4>Users</h4>
      </div>
      <div class="btnAddUser">
        <Link to="/AddUser">
          <button type="button" class="btn btn-success">
            Add User
          </button>
        </Link>
        </div>
      <div className="AppUser">
        <table>
          <tr>
    
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
          
        
          </tr>
          {UList.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val.unm}</td>
                <td>{val.eml}</td>
                <td>{val.rnm}</td>
            
            
              </tr>
            );
          })}
        </table>
      </div>
    </div>
  );
}
export default UserList;