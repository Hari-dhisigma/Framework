
import './AddRole.css';
import { Form, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState } from "react";
import axios from "axios";
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from "react-router-dom";
import Dashboard from "./Dashboard";

function AddRole() {
  const [Role, setRole] = useState("");
  let navigate = useNavigate();


  const RoleInsert = (e) => {
    e.preventDefault();
    
    const u=uuidv4();
   
  let text2 = "R#";
  let s = text2.concat(u);
    console.log(u);
    console.log(s);
    var dt ={
    "TableName":"rol",
        "Item":{
            Pk:u,
            Sk:s,
            rlnm:Role
           
           
        }
      }
      
      
      axios
      .post('http://localhost:8000/insert', dt)
      .then(function (res) {
        console.log(res.data);
        alert("role inserted")
        navigate("/RoleList");
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  return (
    <div className='containerRole'>
      <Dashboard />
        <div className='formRole'>
<Form>

  <Form.Group className="mb-3" controlId="formBasicRole">
    <Form.Label>Role</Form.Label>
   
    <Form.Control type="text" placeholder="Role" value={Role}
              onChange={(e) => setRole(e.target.value)}/>
  </Form.Group>

  <Button variant="primary" type="submit" onClick={(e) =>RoleInsert(e)}>
    Submit
  </Button>
</Form>
    </div>
    </div>
  );
}

export default AddRole;
