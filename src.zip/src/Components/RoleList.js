import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import React, { useEffect, useState } from "react";
import "./RoleList.css";
import Dashboard from "./Dashboard";
import { Link } from "react-router-dom";

function RoleList() {
  const [List, setList] = useState([]);
 
  useEffect(() => {
   
  
    axios
    .get('http://localhost:8000/fetch')
    .then(function (res) {
      console.log(res.data.Items);
      setList(res.data.Items)
    })
    .catch(function (error) {
      console.log(error);
    });
  }, []);
  return (
    <div>
      <Dashboard />
      <div class="containerOrder">
        <h4>Roles</h4>
      </div>
      <div class="btnAddOrder">
        <Link to="/Role">
          <button type="button" class="btn btn-success">
            Add Role
          </button>
        </Link>
        </div>
      <div className="AppRole">
        <table>
          <tr>
           
            <th>Role</th>
        
          </tr>
          {List.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val.rlnm}</td>
            
              </tr>
            );
          })}
        </table>
      </div>
    </div>
  );
}
export default RoleList;